CLEAR TRAY MODEL — Roblox

Files:
- clear_tray.glb   (recommended)
- clear_tray.obj
- clear_tray.mtl

Recommended Roblox Studio settings after importing:
- Material = Glass
- Transparency = 0.45 to 0.60
- Reflectance = 0.03 to 0.08
- Color = RGB(220,245,255)
- CastShadow = false
- CanCollide = false
- Anchored = true

This tray is:
- open at the top
- low and wide
- slightly tapered outward
- designed to look like a transparent acrylic tray
